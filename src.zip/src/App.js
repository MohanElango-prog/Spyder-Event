import React, { useState } from 'react';
import { Button, Form, Container, Header } from 'semantic-ui-react';
import axios from 'axios';
import './App.css';
import { useNavigate } from 'react-router-dom';

function App() {
	const [data, SetData] = useState({name:"",age:"", college:"", department:""});
	
  const navigate = useNavigate();

	const handleSubmit = (e) => {
    console.log(data);
		e.preventDefault();
		// const objt = { name, age, salary, hobby };
		axios
			.post(
				'https://sheet.best/api/sheets/cfe8bcf1-26ad-4299-974e-f2dcc7fa98bd',
				data
			)
			.then((response) => {
				console.log(response);
			});

      navigate('/download', { state: ["jaga","amar","mohan"] })
	};

	return (
		<Container fluid className="container">
			<Header as="h2">React google sheet</Header>
			<Form className="form">
				<Form.Field>
					<label>Name</label>
					<input
						placeholder="Enter your Name"
						onChange={(e) => SetData({...data,name : e.target.value})}
					/>
				</Form.Field>
				<Form.Field>
					<label>Age</label>
					<input
						placeholder="Enter your Age"
						onChange={(e) => SetData({...data,age : e.target.value})}
					/>
				</Form.Field>
				<Form.Field>
					<label>College</label>
					<input
						placeholder="Enter your College"
						onChange={(e) => SetData({...data,college : e.target.value})}
					/>
				</Form.Field>
				<Form.Field>
					<label>Department</label>
					<input
						placeholder="Enter your Department"
						onChange={(e) => SetData({...data,department : e.target.value})}
					/>
				</Form.Field>
				<Button color="blue" type="submit" onClick={handleSubmit}>
        Download Certificate and Continue
				</Button>
			</Form>
		</Container>
	);
}

export default App;