import React, { useRef } from "react";
import { exportComponentAsPNG } from "react-component-export-image";
import { useLocation } from "react-router-dom";
import "./Cdownloader.css";
import certificate from  "./Certificate.jpg";

const CertificateDownloader = () => {
  const location = useLocation();
  let data = location.state;
  return data.map((item) => <Downloader state={{Name:item?.name,Department:item?.department,Event:item.event}}/>)
}

const Downloader = ({ state }) => {
  let certificateWrapper = useRef();
  const Downloader = () => {
    exportComponentAsPNG(certificateWrapper, {
      html2CanvasOptions: { backgroundColor: null },
    });
  };
  return (
    <div className="App">
      <div className="Meta">
        <button
          onClick={() => {
            Downloader();
          }}
        >
          {" "}
          Download
        </button>
      </div>

      <div id="downloadWrapper" ref={certificateWrapper}>
        <div id="certificateWrapper">
          <p>{state.Name}</p>
          <p>{state.Department}</p>
          <p>{state.Event}</p>
          <img
            src={certificate}
            alt="Certificate"
            width={640}
            height={425}
          />
        </div>
      </div>
    </div>
  );
};

export default CertificateDownloader;
