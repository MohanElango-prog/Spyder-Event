// import React from "react";
// import { useNavigate } from "react-router-dom";

// export const Sample = () => {
//     let array = ["jaga","kevin","mohan"]
//     const navigate = useNavigate()
//     return (
//         <button onClick={() => navigate('/download', { state: array })}>Download</button>
//     )
// }